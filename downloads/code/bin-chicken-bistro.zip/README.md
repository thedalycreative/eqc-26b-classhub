# Bin Chicken Bistro

A fine-dining bistro website for the discerning Perth ibis (*Threskiornis molucca*).

A Bootstrap 5 multi-page site demonstrating the framework's core components in a refined editorial / Michelin-parody aesthetic.

## Pages

| File | Purpose |
| --- | --- |
| `index.html` | Home — hero, philosophy intro, featured menu cards, critic carousel |
| `menu.html` | The complete five-course tasting menu, organised by Bootstrap accordion |
| `reviews.html` | Head Critic's reviews of six Perth bins, each opening a Bootstrap modal |
| `about.html` | Origin story, head critic profile, philosophy cards, press quotes |
| `reservations.html` | Booking form with client-side validation, locations grid, contact |

## Bootstrap Components Demonstrated

- Responsive navbar with collapse toggle
- Grid system (rows / cols, breakpoint utilities)
- Cards (custom-styled `.bistro-card`)
- **Carousel** with custom indicators (`index.html` — press quotes)
- **Accordion** (`menu.html` — courses)
- **Modal** ×6 (`reviews.html` — full review pop-ups)
- **Form** with `needs-validation` and submit handler (`reservations.html`)
- Buttons, badges, alerts, sticky-top utility
- Flex/spacing utilities throughout

## Tech

- **Framework:** Bootstrap 5.3.3 (loaded via CDN)
- **Fonts:** Italiana (display) + Cormorant Garamond (body), from Google Fonts
- **No build step** — pure HTML/CSS/JS, runs by opening `index.html` in a browser
- **Custom styling:** `css/styles.css` (CSS variables, overrides Bootstrap defaults)

## Aesthetic

Bone/cream background with oxblood and gold accents. Editorial-magazine feel — generous whitespace, Roman numerals, dotted dividers, decorative ornaments. The comedy lives entirely in the gravity: the site never breaks character.

## Running It

Open `index.html` in any browser. That's it — no install, no build, just files.

---

*Établi MMXXIV · Perth · All Refuse Reserved*
